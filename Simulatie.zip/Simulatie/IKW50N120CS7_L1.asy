Version 4
SymbolType BLOCK
LINE Normal 12 28 4 36
LINE Normal 32 48 12 28
LINE Normal 32 48 4 36
LINE Normal 8 32 -16 16
LINE Normal -16 32 -16 -32
LINE Normal -16 -16 32 -48
LINE Normal 64 -12 32 -12
LINE Normal 64 12 32 12
LINE Normal 32 12 48 -12
LINE Normal 64 12 48 -12
LINE Normal 48 32 48 12
LINE Normal 48 -12 48 -32
LINE Normal -22 32 -22 -32
LINE Normal -64 32 -22 32
LINE Normal 32 80 32 48
LINE Normal 32 -80 32 -48
LINE Normal 48 -52 48 -32
LINE Normal 32 -52 48 -52
LINE Normal 48 51 48 32
LINE Normal 32 51 48 51
RECTANGLE Normal -64 -80 96 80
TEXT 48 -64 Left 2 C
TEXT 48 64 Left 2 E
TEXT -48 16 Left 2 G
WINDOW 0 -16 -80 Bottom 2
WINDOW 3 48 96 Left 0
SYMATTR Value IKW50N120CS7_L1
SYMATTR Prefix X
SYMATTR ModelFile Expo_73.lib
SYMATTR Description Short circuit rugged 1200 V TRENCHSTOP™ IGBT 7 technology
PIN 32 -80 NONE 8
PINATTR PinName C
PINATTR SpiceOrder 1
PIN -64 32 NONE 8
PINATTR PinName G
PINATTR SpiceOrder 2
PIN 32 80 NONE 8
PINATTR PinName E
PINATTR SpiceOrder 3
