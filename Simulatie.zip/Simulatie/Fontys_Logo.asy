Version 4
SymbolType CELL
RECTANGLE Normal -125 -72 125 72

# Dolphin and Capital F
LINE Normal -112 -7 -112 -7
LINE Normal -85 4 -86 8
LINE Normal -86 8 -81 8
LINE Normal -81 8 -83 24
LINE Normal -83 24 -83 24
LINE Normal -83 24 -83 24
LINE Normal -104 -7 -104 -4
LINE Normal -104 -4 -104 0
LINE Normal -104 0 -99 -10
LINE Normal -99 -10 -98 -12
LINE Normal -84 30 -85 41
LINE Normal -85 41 -89 41
LINE Normal -89 41 -89 45
LINE Normal -89 45 -70 45
LINE Normal -70 45 -70 41
LINE Normal -70 41 -75 41
LINE Normal -75 41 -74 30
LINE Normal -74 30 -74 30
LINE Normal -74 30 -74 30
LINE Normal -74 30 -67 30
LINE Normal -67 30 -64 30
LINE Normal -64 30 -62 20
LINE Normal -62 20 -65 20
LINE Normal -65 20 -67 24
LINE Normal -73 24 -71 8
LINE Normal -60 8 -61 14
LINE Normal -61 14 -57 14
LINE Normal -55 4 -85 4
LINE Normal -60 8 -71 8
LINE Normal -67 24 -73 24
LINE Normal -55 4 -57 14
ARC Normal -116 37 63 -24 -54 -14 -54 39
ARC Normal -161 -41 71 336 -81 -52 -122 36
ARC Normal -6 -39 -93 2 -7 -26 -43 -37
ARC Normal 25 -22 -115 61 -19 -24 -55 2
ARC Normal -6 -16 -11 -23 -9 -16 -7 -21
ARC Normal -123 -23 -9 58 -69 -11 -91 -3
ARC Normal -146 -35 86 342 -95 -16 -92 24
ARC Normal 20 -67 -213 319 -21 4 -57 -68
ARC Normal -65 -80 -132 15 -86 -34 -76 -50
ARC Normal -112 31 66 -23 -50 -8 -55 39

# Small letter o
ARC Normal -24 14 -54 30 -31 16 -39 16
ARC Normal -55 13 -6 48 -37 13 -45 45
ARC Normal -51 46 -21 30 -44 44 -36 44
ARC Normal -20 47 -69 12 -38 47 -30 15
ARC Normal -41 18 -32 37 -32 29 -42 -31
ARC Normal -35 42 -44 23 -44 31 -34 91
ARC Normal -46 42 -32 11 -41 56 -23 31
ARC Normal -30 18 -44 49 -35 4 -53 29

# Small letter n
LINE Normal -13 15 -14 20
LINE Normal -14 20 -9 20
LINE Normal -9 20 -12 41
LINE Normal -12 41 -16 41
LINE Normal -16 41 -16 45
LINE Normal -16 45 0 45
LINE Normal 0 45 1 41
LINE Normal 1 41 -2 41
LINE Normal 0 22 6 20
LINE Normal 9 25 7 41
LINE Normal 7 41 5 41
LINE Normal 5 41 4 45
LINE Normal 4 45 21 45
LINE Normal 21 45 21 41
LINE Normal 21 41 17 41
LINE Normal 16 16 14 15
LINE Normal 1 19 1 15
LINE Normal 1 15 -13 15
LINE Normal 0 22 -2 41
LINE Normal 19 24 17 41
ARC Normal 9 20 3 33 9 26 6 20
ARC Normal 19 15 7 32 19 24 18 14
ARC Normal 1 14 17 24 50 -31 -6 19

# Small letter t
LINE Normal 45 6 35 10
LINE Normal 35 10 34 15
LINE Normal 34 15 29 15
LINE Normal 28 20 33 20
LINE Normal 33 20 31 34
LINE Normal 50 43 49 40
LINE Normal 49 40 45 41
LINE Normal 43 20 51 20
LINE Normal 51 20 52 15
LINE Normal 52 15 44 15
LINE Normal 44 15 45 6
LINE Normal 43 20 41 37
LINE Normal 28 20 29 15
ARC Normal 49 41 41 34 41 37 45 41
ARC Normal 31 45 55 22 31 34 82 86

# Small letter y
LINE Normal 79 20 82 20
LINE Normal 82 20 74 34
LINE Normal 74 34 70 20
LINE Normal 70 20 73 20
LINE Normal 73 20 74 15
LINE Normal 74 15 57 15
LINE Normal 57 15 56 20
LINE Normal 56 20 60 20
LINE Normal 60 20 66 44
LINE Normal 66 44 56 62
LINE Normal 56 62 61 62
LINE Normal 61 62 65 62
LINE Normal 65 62 86 20
LINE Normal 86 20 89 20
LINE Normal 89 20 90 15
LINE Normal 90 15 79 15
LINE Normal 79 15 79 20

# Small letter s
LINE Normal 111 24 114 24
LINE Normal 114 24 115 15
LINE Normal 115 15 112 15
LINE Normal 112 15 112 16
LINE Normal 95 36 93 36
LINE Normal 93 36 92 46
LINE Normal 92 46 94 46
LINE Normal 95 43 94 46
ARC Normal 115 46 92 30 89 51 115 38
ARC Normal 93 15 119 31 114 7 96 23
ARC Normal 105 41 95 31 72 36 100 41
ARC Normal 93 37 141 10 84 23 100 47
ARC Normal 95 41 106 34 99 48 103 32
ARC Normal 101 19 111 29 134 24 106 19
ARC Normal 115 24 72 52 129 40 105 17
ARC Normal 111 19 100 26 106 14 104 28

SYMATTR Prefix X
SYMATTR Value Fontys_Logo
